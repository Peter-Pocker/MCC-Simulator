#include "payload.hpp"


void Payload::AddFlits(Flit * f)
{
    _flits.push_back(f);
}